export default function Home(){

    return <>
        <div className="p-5 bg-warning text-white rounded">
            <h1>
                HOME <small>메인 페이지 입니다</small>
            </h1>
        </div>
    </>
}