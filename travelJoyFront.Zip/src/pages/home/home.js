import SideController from "./sideController";

export default function Home(){

    return <>
        {/* 메인페이지 내용 */}
        <div className="mt-4 p-5">
        <SideController/>
        </div>

    </>
}