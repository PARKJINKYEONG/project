
export default function Sample(){

    

    return <>
        <div>
            헤더 이미지 div
        </div>
        <div>
            내용 div
            <div>nav div</div>
            <div>내용</div>
        </div>
    </>
}