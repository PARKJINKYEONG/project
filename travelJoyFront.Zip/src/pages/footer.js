
export default function Footer(){

    const activeStyle={color:'#FFFFFF',fontWeight:'bold'};

    return <>
        <footer class="page-footer font-small blue">				
            <div class="footer-copyright text-center py-3">
                @TravelJoy GitHub <a className="text-body">https://github.com/nineoutof9</a>
            </div>				
        </footer>	
    </>
}